#include "grafik.h"
#include "client.h"

grafik::grafik()
{

}

void grafik::tampil()
{

}
