var class_qwt_alpha_color_map =
[
    [ "QwtAlphaColorMap", "class_qwt_alpha_color_map.html#af78213a5ff1ebef8a8d4447b0987bf32", null ],
    [ "~QwtAlphaColorMap", "class_qwt_alpha_color_map.html#ac6445d25b9df0b565383b8189691bbad", null ],
    [ "color", "class_qwt_alpha_color_map.html#a89acdb9e9918ce37ff219a344cb7330a", null ],
    [ "rgb", "class_qwt_alpha_color_map.html#a15815e2d6637941bc8e806afbb99c170", null ],
    [ "setColor", "class_qwt_alpha_color_map.html#a372ba8791102270991473897fb36a965", null ]
];