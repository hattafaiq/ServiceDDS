var class_qwt_compass_rose =
[
    [ "~QwtCompassRose", "class_qwt_compass_rose.html#a9e3e5086d7225152cad3a276096753be", null ],
    [ "draw", "class_qwt_compass_rose.html#ad974a3035da51a9cfb36fa04eb1c40a6", null ],
    [ "palette", "class_qwt_compass_rose.html#ad825ddd8422f480c312bad1dcd8bf681", null ],
    [ "setPalette", "class_qwt_compass_rose.html#ad69f887ed012d6bf6bf2ffeb133e26d5", null ]
];