var class_qwt_event_pattern_1_1_key_pattern =
[
    [ "KeyPattern", "class_qwt_event_pattern_1_1_key_pattern.html#ac52d2d39d519c750194462c8da4c8ec2", null ],
    [ "key", "class_qwt_event_pattern_1_1_key_pattern.html#af13072b058c3abbb591450b82f049dd6", null ],
    [ "modifiers", "class_qwt_event_pattern_1_1_key_pattern.html#a1db88ed291d4ba49fa84e32e86fa10d1", null ]
];