var class_qwt_plot_rescaler =
[
    [ "ExpandingDirection", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585", [
      [ "ExpandUp", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a10adc202ca84a06179b905db6802668c", null ],
      [ "ExpandDown", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a856d9a1fe75ed6398a1b3c4b60f3fbfd", null ],
      [ "ExpandBoth", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a3dfb8208dfb62200761e4221763db033", null ]
    ] ],
    [ "RescalePolicy", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6a", [
      [ "Fixed", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aab8f9ce10c092bee12de74b05a46b6e9c", null ],
      [ "Expanding", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aac0b9db1ea3c5666792c2a9813ca5d7e1", null ],
      [ "Fitting", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aa30a43b11d9df23f66110b65d1e249db1", null ]
    ] ],
    [ "QwtPlotRescaler", "class_qwt_plot_rescaler.html#a4bef342d0a571af31685c2ff88def5d5", null ],
    [ "~QwtPlotRescaler", "class_qwt_plot_rescaler.html#ae34a0dbae9074c211f36c765142d8ddd", null ],
    [ "aspectRatio", "class_qwt_plot_rescaler.html#a76bc7cc4987b1572e12431b8128500ae", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#ad4aa9bf81032b822b848774ee21142ce", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#a49e3d4084037f6786c5bb6a8d2c78047", null ],
    [ "canvasResizeEvent", "class_qwt_plot_rescaler.html#a5490a4a1b576b1118c095cc54810e2aa", null ],
    [ "eventFilter", "class_qwt_plot_rescaler.html#a2a6809f3940b9114a1faed30f6edc3d0", null ],
    [ "expandingDirection", "class_qwt_plot_rescaler.html#acdd929d4b55be6956acd4ec5d0df9467", null ],
    [ "expandInterval", "class_qwt_plot_rescaler.html#a3dfd3bd03394c66ede8e37478d32784c", null ],
    [ "expandScale", "class_qwt_plot_rescaler.html#a163fd15cb5e6fa1c855ff069f1711c5c", null ],
    [ "interval", "class_qwt_plot_rescaler.html#afa1a81034796b68339fcb71ef179c394", null ],
    [ "intervalHint", "class_qwt_plot_rescaler.html#ac3f9475494b33ebc1a1e8103e327d56b", null ],
    [ "isEnabled", "class_qwt_plot_rescaler.html#a85a9b40054acaab051f3679db1547b81", null ],
    [ "orientation", "class_qwt_plot_rescaler.html#a6a4435f91c459517db9e08bd30b1ad37", null ],
    [ "plot", "class_qwt_plot_rescaler.html#aca7a946dd53744e4640be383cd161a7c", null ],
    [ "plot", "class_qwt_plot_rescaler.html#ae54220a61cab777a6cb60103091a0aa3", null ],
    [ "referenceAxis", "class_qwt_plot_rescaler.html#a207a8382199ab99a91d9c93d27aa5cf2", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#af4b1840575eb6812c23acd9be199e5df", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#a1a98f9c7a1102e486ce81a2833799155", null ],
    [ "rescalePolicy", "class_qwt_plot_rescaler.html#ac5a49fa34b071da28517efe6212d81ea", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#a31f71937b4cff3e60f74db83beb6d2de", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#aa747f1cf3ecc3a37f98d0972e1db600b", null ],
    [ "setEnabled", "class_qwt_plot_rescaler.html#a6f1c886d127ec4943552170dc63edf29", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#aa2ecffbc14d951ab9f1809c14bc4e21b", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#a1681eb01b65b91e8b2583d87f890576f", null ],
    [ "setIntervalHint", "class_qwt_plot_rescaler.html#afefb0ec065ff855785d0198fc04a07d3", null ],
    [ "setReferenceAxis", "class_qwt_plot_rescaler.html#a6f13d60cc1e1071a6830ea30ccbcca37", null ],
    [ "setRescalePolicy", "class_qwt_plot_rescaler.html#ae6b7df41b5387d0aed532559546e40b6", null ],
    [ "syncScale", "class_qwt_plot_rescaler.html#a21f64ee537246c96bb724f09f3a6524c", null ],
    [ "updateScales", "class_qwt_plot_rescaler.html#aaead8df76bb22831577fd11ed6d46e5a", null ]
];