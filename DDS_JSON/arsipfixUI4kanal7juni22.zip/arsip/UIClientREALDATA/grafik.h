#ifndef GRAFIK_H
#define GRAFIK_H


class grafik
{
public:
    grafik();
    void tampil();
};

#endif // GRAFIK_H
