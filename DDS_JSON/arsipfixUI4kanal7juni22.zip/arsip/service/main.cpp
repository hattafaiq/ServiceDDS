#include <QCoreApplication>
#include "data.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    data masuk;
    masuk.init_time();

    return a.exec();
}
